@echo off
setlocal enabledelayedexpansion

set REMOTE_NAME=origin
set BRANCH_NAME=main
set COMMIT_MESSAGE=آپلود کامل پروژه به گیت‌هاب 🚀

:: آیا پروژه گیت دارد؟
if not exist .git (
    git init -b %BRANCH_NAME%
    echo گیت راه‌اندازی شد.
)

:: اضافه کردن تمام فایل‌ها
git add .

:: بررسی تغییرات
git diff --cached --quiet
if errorlevel 1 (
    git commit -m "%COMMIT_MESSAGE%"
    echo تغییرات کامیت شد.
) else (
    echo فایلی برای کامیت وجود ندارد.
)

:: آیا remote تعریف شده؟
git remote | findstr %REMOTE_NAME% >nul
if errorlevel 1 (
    set /p REMOTE_URL=آدرس GitHub را وارد کنید:
    git remote add %REMOTE_NAME% !REMOTE_URL!
    echo مخزن اضافه شد.
)

git push -u %REMOTE_NAME% %BRANCH_NAME%
echo آپلود با موفقیت انجام شد! 🎉
pause
