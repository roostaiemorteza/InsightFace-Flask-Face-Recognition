import os

folder = "known_faces"

files = sorted(
    f for f in os.listdir(folder)
    if f.lower().endswith((".jpg", ".jpeg", ".png"))
)

counters = {
    "ronaldo": 0,
    "messi": 0,
    "other": 0,
}

for filename in files:
    ext = os.path.splitext(filename)[1].lower()
    lower_name = filename.lower()

    if "ronaldo" in lower_name:
        prefix = "ronaldo"
        counters["ronaldo"] += 1
        number = counters["ronaldo"]
    elif "messi" in lower_name:
        prefix = "messi"
        counters["messi"] += 1
        number = counters["messi"]
    else:
        prefix = "other"
        counters["other"] += 1
        number = counters["other"]

    new_name = f"{prefix}{number}{ext}"

    if filename != new_name:
        os.rename(
            os.path.join(folder, filename),
            os.path.join(folder, new_name)
        )

    print(f"Renamed {filename} → {new_name}")
